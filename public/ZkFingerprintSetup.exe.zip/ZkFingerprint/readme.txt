1. setup.exe ZkTeco driver суулгана уу.
2. Төхөөрөмжөө залгана уу.
3. ZkFingerprintSetup.exe хуруунын хээ уншигч програмыг суулгана уу.